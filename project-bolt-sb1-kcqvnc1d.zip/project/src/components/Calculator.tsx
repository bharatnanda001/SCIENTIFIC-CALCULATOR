import React, { useState } from 'react';
import { 
  Divide, 
  Minus, 
  Plus, 
  X, 
  RotateCcw, 
  Square, 
  Percent,
  Power
} from 'lucide-react';

type Operation = 'sin' | 'cos' | 'tan' | 'log' | 'ln' | 'sqrt' | 'square' | 'pow' | '+' | '-' | '*' | '/' | '%';

export default function Calculator() {
  const [display, setDisplay] = useState('0');
  const [memory, setMemory] = useState<number | null>(null);
  const [operation, setOperation] = useState<Operation | null>(null);
  const [newNumber, setNewNumber] = useState(true);

  const calculate = (a: number, b: number, op: Operation): number => {
    switch (op) {
      case '+': return a + b;
      case '-': return a - b;
      case '*': return a * b;
      case '/': return a / b;
      case '%': return a % b;
      case 'pow': return Math.pow(a, b);
      default: return b;
    }
  };

  const handleNumber = (num: string) => {
    if (newNumber) {
      setDisplay(num);
      setNewNumber(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const handleDecimal = () => {
    if (newNumber) {
      setDisplay('0.');
      setNewNumber(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleOperation = (op: Operation) => {
    const current = parseFloat(display);
    
    if (memory === null) {
      setMemory(current);
    } else if (operation) {
      const result = calculate(memory, current, operation);
      setMemory(result);
      setDisplay(result.toString());
    }
    
    setOperation(op);
    setNewNumber(true);
  };

  const handleScientific = (func: string) => {
    const current = parseFloat(display);
    let result: number;

    switch (func) {
      case 'sin':
        result = Math.sin(current * Math.PI / 180);
        break;
      case 'cos':
        result = Math.cos(current * Math.PI / 180);
        break;
      case 'tan':
        result = Math.tan(current * Math.PI / 180);
        break;
      case 'log':
        result = Math.log10(current);
        break;
      case 'ln':
        result = Math.log(current);
        break;
      case 'sqrt':
        result = Math.sqrt(current);
        break;
      case 'square':
        result = current * current;
        break;
      default:
        return;
    }

    setDisplay(result.toString());
    setNewNumber(true);
  };

  const handleEquals = () => {
    if (memory === null || operation === null) return;
    
    const current = parseFloat(display);
    const result = calculate(memory, current, operation);
    
    setDisplay(result.toString());
    setMemory(null);
    setOperation(null);
    setNewNumber(true);
  };

  const handleClear = () => {
    setDisplay('0');
    setMemory(null);
    setOperation(null);
    setNewNumber(true);
  };

  return (
    <div className="bg-gray-900 p-6 rounded-2xl shadow-2xl w-[360px]">
      <div className="bg-gray-800 p-4 rounded-xl mb-4">
        <div className="text-right text-3xl font-mono text-white overflow-hidden">
          {display}
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {/* Scientific Functions */}
        <button onClick={() => handleScientific('sin')} className="btn-sci">sin</button>
        <button onClick={() => handleScientific('cos')} className="btn-sci">cos</button>
        <button onClick={() => handleScientific('tan')} className="btn-sci">tan</button>
        <button onClick={handleClear} className="btn-red">
          <RotateCcw size={20} />
        </button>

        <button onClick={() => handleScientific('log')} className="btn-sci">log</button>
        <button onClick={() => handleScientific('ln')} className="btn-sci">ln</button>
        <button onClick={() => handleScientific('sqrt')} className="btn-sci">√</button>
        <button onClick={() => handleOperation('%')} className="btn-op">
          <Percent size={20} />
        </button>

        <button onClick={() => handleScientific('square')} className="btn-sci">
          <Square size={20} />
        </button>
        <button onClick={() => handleOperation('pow')} className="btn-sci">
          <Power size={20} />
        </button>
        <button onClick={() => handleOperation('/')} className="btn-op">
          <Divide size={20} />
        </button>
        <button onClick={() => handleOperation('*')} className="btn-op">
          <X size={20} />
        </button>

        {/* Numbers and Basic Operations */}
        <button onClick={() => handleNumber('7')} className="btn-num">7</button>
        <button onClick={() => handleNumber('8')} className="btn-num">8</button>
        <button onClick={() => handleNumber('9')} className="btn-num">9</button>
        <button onClick={() => handleOperation('-')} className="btn-op">
          <Minus size={20} />
        </button>

        <button onClick={() => handleNumber('4')} className="btn-num">4</button>
        <button onClick={() => handleNumber('5')} className="btn-num">5</button>
        <button onClick={() => handleNumber('6')} className="btn-num">6</button>
        <button onClick={() => handleOperation('+')} className="btn-op">
          <Plus size={20} />
        </button>

        <button onClick={() => handleNumber('1')} className="btn-num">1</button>
        <button onClick={() => handleNumber('2')} className="btn-num">2</button>
        <button onClick={() => handleNumber('3')} className="btn-num">3</button>
        <button onClick={handleEquals} className="btn-equals row-span-2">=</button>

        <button onClick={() => handleNumber('0')} className="btn-num col-span-2">0</button>
        <button onClick={handleDecimal} className="btn-num">.</button>
      </div>
    </div>
  );
}